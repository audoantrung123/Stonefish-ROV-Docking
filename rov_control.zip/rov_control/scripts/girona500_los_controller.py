#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os, math, datetime
import numpy as np
import rospy
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64MultiArray
from tf.transformations import euler_from_quaternion

# ---- vẽ không cần X server
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


# ==================== PID ====================
class PID:
    def __init__(self, Kp=0.0, Ki=0.0, Kd=0.0,
                 output_limits=(-1.0, 1.0), anti_windup=5.0):
        self.Kp, self.Ki, self.Kd = Kp, Ki, Kd
        self.min_out, self.max_out = output_limits
        self.i_max = anti_windup
        self.integral = 0.0
        self.prev_err = 0.0
        self.last_t = None

    def reset(self):
        self.integral = 0.0
        self.prev_err = 0.0
        self.last_t = None

    def step(self, err, now):
        if self.last_t is None:
            self.last_t = now
            self.prev_err = err
            return float(np.clip(self.Kp * err, self.min_out, self.max_out))
        dt = (now - self.last_t).to_sec()
        if dt <= 0.0:
            return float(np.clip(self.Kp * err + self.Ki * self.integral,
                                 self.min_out, self.max_out))
        self.integral += err * dt
        self.integral = float(np.clip(self.integral, -self.i_max, self.i_max))
        d = (err - self.prev_err) / dt
        u = self.Kp * err + self.Ki * self.integral + self.Kd * d
        self.prev_err = err
        self.last_t = now
        return float(np.clip(u, self.min_out, self.max_out))


# =============== Geometry helpers ===============
def wrap_pi(a):
    while a > math.pi:
        a -= 2.0 * math.pi
    while a < -math.pi:
        a += 2.0 * math.pi
    return a


def segment_proj(p, a, b):
    """
    Project point p to segment a->b.
    Returns: (qx,qy), s (0..1), cte, (tx,ty), (nx,ny), seg_len
    cte: signed cross-track error (left positive).
    """
    ax, ay = a
    bx, by = b
    px, py = p
    vx, vy = bx - ax, by - ay
    L2 = vx * vx + vy * vy
    if L2 < 1e-12:
        t = 0.0
        qx, qy = ax, ay
        tx, ty = 1.0, 0.0
        seg_len = 0.0
    else:
        t = ((px - ax) * vx + (py - ay) * vy) / L2
        t = max(0.0, min(1.0, t))
        qx, qy = ax + t * vx, ay + t * vy
        seg_len = math.sqrt(L2)
        norm = seg_len + 1e-9
        tx, ty = vx / norm, vy / norm
    nx, ny = -ty, tx
    dx, dy = px - qx, py - qy
    cte = dx * nx + dy * ny
    return (qx, qy), t, cte, (tx, ty), (nx, ny), seg_len


# ==================== Main Node ====================
class Node:
    def __init__(self):
        rospy.init_node("girona500_los_controller")

        # ---- Basic params ----
        self.robot_name = rospy.get_param("~robot_name", "GIRONA500")
        self.save_dir = os.path.expanduser(rospy.get_param("~save_dir", "~/.ros"))

        # Stonefish NED: z dương xuống
        self.z_is_down = rospy.get_param("~z_is_down", True)

        # Signs (Stonefish thrusters in scenario use inverted_setpoint="true")
        self.surge_sign = rospy.get_param("~surge_sign", -1.0)
        self.sway_sign = rospy.get_param("~sway_sign", -1.0)
        self.heave_sign = rospy.get_param("~heave_sign", -1.0)
        self.yaw_sign = rospy.get_param("~yaw_sign", +1.0)

        # Feed-forward heave to counter buoyancy (negative = push down)
        self.heave_bias = rospy.get_param("~heave_bias", -0.18)

        # ---- Guidance mode (Fossen): 'los' or 'ilos' ----
        self.guidance = rospy.get_param("~guidance", "los")
        self.k_y = rospy.get_param("~k_y", 1.1)       # lateral gain
        self.k_i = rospy.get_param("~k_i", 0.0)       # iLOS integral gain (start with 0)
        self.ey_int_lim = rospy.get_param("~ey_int_lim", 3.0)
        self.ey_int = 0.0
        self._last_guidance_t = None

        # Lookahead distance Δ (dynamic with speed)
        self.Delta_min = rospy.get_param("~Delta_min", 2.1)
        self.Delta_max = rospy.get_param("~Delta_max", 3.6)
        self.k_Delta = rospy.get_param("~k_Delta", 1.3)

        # --- Speed governor: U^2*|kappa| <= a_lat_max ---
        self.U_min     = rospy.get_param("~U_min", 0.20)
        self.U_max     = rospy.get_param("~U_max", 0.48)
        self.a_lat_max = rospy.get_param("~a_lat_max", 0.09)   # m/s^2
        self.U_alpha   = rospy.get_param("~U_alpha", 0.9)     # low-pass on Uref
        self.kappa_eps = 1e-3
        self.Uref_filt = self.U_min
        
                # Switch segment radius (cho phép chỉnh bằng param)
        self.switch_radius = rospy.get_param("~switch_radius", 1.3)

        # Corner anticipation (trộn hướng 2 đoạn để bẻ lái sớm)
        self.corner_enable    = rospy.get_param("~corner_enable", True)
        self.corner_deg_min   = rospy.get_param("~corner_deg_min", 20.0)   # chỉ kích hoạt khi góc đổi hướng > 20°
        self.corner_gain      = rospy.get_param("~corner_gain", 1.05)      # 0..1.5 – mức trộn
        self.corner_ld_shrink = rospy.get_param("~corner_ld_shrink", 0.55) # rút Δ khi gần góc
        self.corner_slow_max  = rospy.get_param("~corner_slow_max", 0.55)  # giảm Uref tối đa khi sát góc


        # --- PID gains (tuned) ---
        self.pid_yaw   = PID(Kp=1.55, Ki=0.00, Kd=0.45, output_limits=(-0.7, 0.7))
        # iLOS đã xử lý lệch ngang bằng góc; sway PID chỉ hỗ trợ nhẹ
        self.pid_cte   = PID(Kp=0.12, Ki=0.00, Kd=0.05, output_limits=(-0.6, 0.6))
        self.pid_surge = PID(Kp=0.4, Ki=0.00, Kd=0.08, output_limits=(-0.9, 0.9))
        self.pid_heave = PID(Kp=0.80, Ki=0.06, Kd=1.10, output_limits=(-0.9, 0.9),
                             anti_windup=0.5)

        # Waypoints (x, y, z_depth); depth is NED (+down)
        self.waypoints = rospy.get_param("~waypoints", [
            [10.0,  0.0, 15.0],
            [10.0, 10.0, 15.0],
            [ 0.0, 10.0, 15.0],
            [ 0.0,  0.0, 15.0],
            [ 0.0,  0.0,  2.0],
        ])

        # State
        self.px = self.py = self.pz = 0.0
        self.yaw = 0.0
        self.ux = self.uy = 0.0
        self.have_odom = False
        self.seg_i = 0

        # Log for plotting
        self.t0 = None
        # (t, x, y, z, x_ref, y_ref, z_ref, seg, cte, Delta, kappa, Uref)
        self.log = []

        # ROS I/O
        self.pub_thr = rospy.Publisher(f"/{self.robot_name}/thruster_setpoints",
                                       Float64MultiArray, queue_size=1)
        rospy.Subscriber(f"/{self.robot_name}/dynamics", Odometry, self.cb_odom)

        rospy.loginfo("AUV GIRONA500 LOS/iLOS controller ready.")
        self.wait_odom()

    # ------------------- ROS utils -------------------
    def wait_odom(self):
        rospy.loginfo("Đợi Odometry...")
        r = rospy.Rate(50)
        while not rospy.is_shutdown() and not self.have_odom:
            r.sleep()
        rospy.loginfo("Đã nhận Odometry đầu tiên.")

    def cb_odom(self, msg):
        self.px = msg.pose.pose.position.x
        self.py = msg.pose.pose.position.y
        self.pz = msg.pose.pose.position.z  # NED (+down)
        q = msg.pose.pose.orientation
        _, _, self.yaw = euler_from_quaternion([q.x, q.y, q.z, q.w])
        self.ux = msg.twist.twist.linear.x
        self.uy = msg.twist.twist.linear.y
        if not self.have_odom:
            self.have_odom = True
            self.t0 = rospy.Time.now()

    # ---------------- allocation & publish ----------------
    def send(self, surge_cmd, sway_cmd, heave_cmd, yaw_cmd):
        """
        Thruster layout:
          [SurgePort, SurgeStarboard, HeaveBow, HeaveStern, Sway]
        All commands normalized [-1, 1].
        """
        k_yaw_mix = 1.0
        surge_cmd *= self.surge_sign
        sway_cmd *= self.sway_sign

        sp = np.clip(surge_cmd - k_yaw_mix * self.yaw_sign * yaw_cmd, -1.0, 1.0)
        ss = np.clip(surge_cmd + k_yaw_mix * self.yaw_sign * yaw_cmd, -1.0, 1.0)
        hb = np.clip(heave_cmd, -1.0, 1.0)
        hs = np.clip(heave_cmd, -1.0, 1.0)
        sy = np.clip(sway_cmd, -1.0, 1.0)

        msg = Float64MultiArray()
        msg.data = [float(sp), float(ss), float(hb), float(hs), float(sy)]
        self.pub_thr.publish(msg)

    # ---------------- plotting ----------------
    def save_plots(self):
        if not self.log:
            rospy.logwarn("Không có log để vẽ.")
            return []
        os.makedirs(self.save_dir, exist_ok=True)
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        base = os.path.join(self.save_dir, f"auv_los_{ts}")

        arr = np.array(self.log)
        t = arr[:, 0]
        x, y, z = arr[:, 1], arr[:, 2], arr[:, 3]
        xref, yref, zref = arr[:, 4], arr[:, 5], arr[:, 6]
        cte = arr[:, 8]

        # 1) Top-down XY
        plt.figure(figsize=(7, 6))
        wps = np.array(self.waypoints)
        plt.plot(wps[:, 0], wps[:, 1], 'k--', lw=1.5, label='Reference path (WP)')
        plt.scatter(wps[:, 0], wps[:, 1], c='k', s=25)
        plt.plot(x, y, label='AUV trajectory')
        plt.plot(xref, yref, alpha=0.7, label='Lookahead (ref)')
        plt.axis('equal')
        plt.xlabel('X [m]'); plt.ylabel('Y [m]')
        plt.title('Top view (XY)')
        plt.grid(True, ls=':')
        plt.legend()
        f1 = base + "_xy.png"
        plt.savefig(f1, dpi=150); plt.close()

        # 2) Depth
        plt.figure(figsize=(8, 4))
        plt.plot(t, z, label='Depth z (meas)')
        plt.plot(t, zref, label='Depth z_ref', alpha=0.8)
        plt.xlabel('Time [s]'); plt.ylabel('Depth z (NED, +down) [m]')
        plt.title('Depth tracking')
        plt.grid(True, ls=':'); plt.legend()
        f2 = base + "_depth.png"
        plt.savefig(f2, dpi=150); plt.close()

        # 3) CTE
        plt.figure(figsize=(8, 4))
        plt.plot(t, cte)
        plt.xlabel('Time [s]'); plt.ylabel('CTE [m]')
        plt.title('Cross-Track Error'); plt.grid(True, ls=':')
        f3 = base + "_cte.png"
        plt.savefig(f3, dpi=150); plt.close()

        rospy.loginfo("Đã lưu hình: %s, %s, %s", f1, f2, f3)
        return [f1, f2, f3]


    # ---------------- controller core ----------------
    def run(self):
        rate = rospy.Rate(20)

        rospy.loginfo("Bắt đầu bám quỹ đạo: %d điểm.", len(self.waypoints))
        for k in range(len(self.waypoints) - 1):
            rospy.loginfo("→ Segment %d: %s → %s", k + 1, self.waypoints[k], self.waypoints[k + 1])

        while not rospy.is_shutdown() and self.seg_i < len(self.waypoints) - 1:
            now = rospy.Time.now()

            A = self.waypoints[self.seg_i]
            B = self.waypoints[self.seg_i + 1]

            # Project vị trí hiện tại lên đoạn A->B
            (qx, qy), s, cte, (tx, ty), (nx, ny), seg_len = segment_proj(
                (self.px, self.py), (A[0], A[1]), (B[0], B[1])
            )

            # [1] Switch segment dùng self.switch_radius
            dist_end = math.hypot(B[0] - self.px, B[1] - self.py)
            if dist_end < self.switch_radius:
                self.seg_i += 1
                self.pid_cte.reset()
                self.pid_yaw.reset()
                self.pid_surge.reset()
                if self.seg_i >= len(self.waypoints) - 1:
                    break
                continue

            # Vận tốc & lookahead Δ động
            u = math.hypot(self.ux, self.uy)
            Delta = float(np.clip(self.Delta_min + self.k_Delta * u,
                                  self.Delta_min, self.Delta_max))

            # Tham chiếu mặc định: theo tiếp tuyến đoạn hiện tại
            x_ref = qx + tx * Delta
            y_ref = qy + ty * Delta
            tdx, tdy = tx, ty

            # [2] Corner anticipation / blending
            w_corner = 0.0
            if self.corner_enable and (self.seg_i < len(self.waypoints) - 2):
                # tiếp tuyến đoạn hiện tại t1
                t1x, t1y = tx, ty
                # tiếp tuyến đoạn kế tiếp t2 (B->C)
                C = self.waypoints[self.seg_i + 2]
                v2x, v2y = (C[0] - B[0]), (C[1] - B[1])
                n2 = math.hypot(v2x, v2y) + 1e-9
                t2x, t2y = v2x / n2, v2y / n2
                # góc giữa hai đoạn
                dot = max(-1.0, min(1.0, t1x * t2x + t1y * t2y))
                theta_deg = math.degrees(math.acos(dot))
                if theta_deg >= self.corner_deg_min:
                    a_lat_max = max(self.a_lat_max, 1e-6)
                    Rmin = max(u * u / a_lat_max, 0.5)
                    d_corner = 0.5 * Delta + Rmin * math.tan(math.radians(theta_deg) / 2.0)
                    w_corner = float(np.clip(1.0 - dist_end / max(d_corner, 1e-6), 0.0, 1.0))
                    w_corner *= self.corner_gain
                    w_corner = float(np.clip(w_corner, 0.0, 1.0))
                    if w_corner > 0.0:
                        Delta_eff = Delta * (1.0 - self.corner_ld_shrink * w_corner)
                        Delta_eff = float(np.clip(Delta_eff, 0.5 * self.Delta_min, self.Delta_max))
                        tbx = (1.0 - w_corner) * t1x + w_corner * t2x
                        tby = (1.0 - w_corner) * t1y + w_corner * t2y
                        n_tb = math.hypot(tbx, tby) + 1e-9
                        tbx, tby = tbx / n_tb, tby / n_tb
                        x_ref = self.px + tbx * Delta_eff
                        y_ref = self.py + tby * Delta_eff
                        tdx, tdy = tbx, tby
                        Delta = Delta_eff

            # Hướng tiếp tuyến dùng cho LOS/iLOS
            psi_p = math.atan2(tdy, tdx)

            # iLOS integral
            if self._last_guidance_t is None:
                dt = 1.0 / 20.0
            else:
                dt = (now - self._last_guidance_t).to_sec()
                if dt <= 0.0 or dt > 1.0:
                    dt = 1.0 / 20.0
            self._last_guidance_t = now

            if self.guidance == "ilos" and self.k_i > 0.0:
                self.ey_int += self.k_i * cte * dt
                self.ey_int = float(np.clip(self.ey_int, -self.ey_int_lim, self.ey_int_lim))
                ey_term = cte + self.ey_int
            else:
                ey_term = cte

            # LOS/iLOS desired heading
            psi_d = psi_p - math.atan2(self.k_y * ey_term, Delta)
            e_yaw = wrap_pi(psi_d - self.yaw)
            yaw_cmd = self.pid_yaw.step(e_yaw, now)

            # Governor theo a_lat_max
            alpha = e_yaw
            kappa = (2.0 * math.sin(alpha)) / max(Delta, 1e-3)
            U_cap = math.sqrt(max(self.a_lat_max, 1e-6) / max(abs(kappa), self.kappa_eps))
            Uref_des = float(np.clip(U_cap, self.U_min, self.U_max))
            if w_corner > 0.0:
                Uref_des *= (1.0 - self.corner_slow_max * w_corner)
            self.Uref_filt = self.U_alpha * self.Uref_filt + (1.0 - self.U_alpha) * Uref_des
            Uref = self.Uref_filt

            # SURGE: bám khoảng cách tới lookahead + feedforward
            ex_b = (x_ref - self.px) * math.cos(self.yaw) + (y_ref - self.py) * math.sin(self.yaw)
            surge = self.pid_surge.step(ex_b, now)
            surge = float(np.clip(0.45 * Uref + 0.55 * surge, -0.9, 0.9))

            # SWAY (tùy chọn)
            sway = self.pid_cte.step(cte, now)

            # HEAVE (độ sâu, NED +down)
            z_meas = self.pz if self.z_is_down else -self.pz
            z_ref = B[2]
            ez = z_ref - z_meas
            heave = self.heave_sign * self.pid_heave.step(ez, now) + self.heave_bias
            heave = float(np.clip(heave, -1.0, 1.0))

            # Gửi lệnh
            self.send(surge, sway, heave, yaw_cmd)

            # Log
            tsec = (now - self.t0).to_sec() if self.t0 is not None else 0.0
            self.log.append([tsec, self.px, self.py, z_meas, x_ref, y_ref, z_ref,
                             self.seg_i, cte, Delta, kappa, Uref])

            rospy.loginfo_throttle(
                0.7,
                ("Seg %d | Pos x=%.2f y=%.2f z=%.2f | ref x=%.2f y=%.2f | "
                 "u≈%.02f Δ=%.2f cte=%.2f κ=%.3f Uref=%.2f | ψerr=%.1f° | "
                 "cmd(su=%.2f, sw=%.2f, hv=%.2f, yw=%.2f)"),
                self.seg_i + 1, self.px, self.py, z_meas,
                x_ref, y_ref, u, Delta, cte, kappa, Uref,
                math.degrees(e_yaw), surge, sway, heave, yaw_cmd
            )

            rate.sleep()

        # stop
        self.send(0.0, 0.0, 0.0, 0.0)
        rospy.loginfo("Hoàn thành quỹ đạo.")
        self.save_plots()



if __name__ == "__main__":
    try:
        Node().run()
    except rospy.ROSInterruptException:
        pass

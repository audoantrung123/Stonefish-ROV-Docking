#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import math
import rospy
from std_msgs.msg import Float64MultiArray
from nav_msgs.msg import Odometry
from tf.transformations import euler_from_quaternion

def sat(x, lo, hi): 
    return max(lo, min(x, hi))

def wrap_pi(a):
    while a > math.pi: 
        a -= 2.0*math.pi
    while a < -math.pi: 
        a += 2.0*math.pi
    return a

class SimplePID:
    def __init__(self, Kp, Ki, Kd, out_lim=(-1.0, 1.0), i_lim=1.0):
        self.Kp, self.Ki, self.Kd = Kp, Ki, Kd
        self.out_lo, self.out_hi = out_lim
        self.i_lim = i_lim
        self.e_prev = 0.0
        self.i = 0.0
        self.t_prev = None

    def reset(self):
        self.e_prev = 0.0
        self.i = 0.0
        self.t_prev = None

    def step(self, e, t):
        if self.t_prev is None:
            self.t_prev = t
            self.e_prev = e
            return 0.0
        dt = (t - self.t_prev).to_sec()
        if dt <= 0.0:
            return 0.0
        self.i += e * dt
        self.i = sat(self.i, -self.i_lim, self.i_lim)
        d = (e - self.e_prev) / dt
        u = self.Kp * e + self.Ki * self.i + self.Kd * d
        u = sat(u, self.out_lo, self.out_hi)
        self.e_prev = e
        self.t_prev = t
        return u

class SlewLimiter:
    """Giới hạn tốc độ thay đổi lệnh để mượt mà nhưng vẫn mạnh."""
    def __init__(self, rate_up=3.5, rate_down=4.0):
        self.rate_up = rate_up
        self.rate_down = rate_down
        self.prev = 0.0
        self.t_prev = None

    def step(self, u, t):
        if self.t_prev is None:
            self.prev = u
            self.t_prev = t
            return u
        dt = (t - self.t_prev).to_sec()
        if dt <= 0.0:
            return self.prev
        du = u - self.prev
        lim = self.rate_up * dt if du >= 0.0 else self.rate_down * dt
        du = sat(du, -abs(lim), abs(lim))
        self.prev += du
        self.t_prev = t
        return self.prev

class BlueROV2Controller:
    """
    2 pha (NED: z dương xuống):
      PHA_1_DESCEND:   chỉ heave về z = target_z.
      PHA_2_CRUISE_X:  giữ z, giữ yaw (tại thời điểm chuyển pha), khóa y=y_lock, chạy thẳng theo x tới x=target_x.
    In:
      /<veh>/odometry (nav_msgs/Odometry, frame 'world_ned')
    Out:
      /<veh>/setpoint/pwm  (Float64MultiArray, 8 kênh, normalized [-1,1])
    Thứ tự actuator (khớp .scn bạn gửi):
      1: FrontRight, 2: FrontLeft, 3: BackRight, 4: BackLeft,
      5: DiveFrontRight, 6: DiveFrontLeft, 7: DiveBackRight, 8: DiveBackLeft
    """
    PHA_1_DESCEND = 1
    PHA_2_CRUISE_X = 2

    def __init__(self):
        rospy.init_node("bluerov2_2phase_controller")

        # --------- Params ----------
        self.veh = rospy.get_param("~vehicle_name", "bluerov2")
        self.rate_hz = float(rospy.get_param("~rate", 50.0))
        self.odom_topic = rospy.get_param("~odom_topic", f"/{self.veh}/odometry")

        # Mục tiêu (m) — NED: z dương xuống
        self.tx = float(rospy.get_param("~target_x", 10.0))
        self.tz = float(rospy.get_param("~target_z", 5.0))

        # Ngưỡng & thời gian giữ khi đạt độ sâu
        self.z_tol = float(rospy.get_param("~z_tol", 0.08))      # m
        self.hold_time = float(rospy.get_param("~hold_time", 0.8))  # s

        # Gains mạnh hơn
        self.k_yaw = float(rospy.get_param("~k_yaw", 1.6))
        self.k_v   = float(rospy.get_param("~k_v",   1.2))
        self.k_lat = float(rospy.get_param("~k_lat", 1.0))

        # Biên lệnh lớn
        self.u_max = float(rospy.get_param("~u_max", 1.0))
        self.r_max = float(rospy.get_param("~r_max", 0.9))

        # Heave PID (mạnh + dải rộng)
        self.pid_z = SimplePID(Kp=2.2, Ki=0.25, Kd=0.4, out_lim=(-1.0, 1.0), i_lim=1.5)

        # Slew limiters
        self.slew_X = SlewLimiter(rate_up=3.5, rate_down=4.0)
        self.slew_Y = SlewLimiter(rate_up=3.5, rate_down=4.0)
        self.slew_R = SlewLimiter(rate_up=4.0,  rate_down=4.5)
        self.slew_H = SlewLimiter(rate_up=4.0,  rate_down=4.0)

        # Cho phép lật dấu logic theo thực nghiệm (KHÔNG can thiệp inverted_setpoint trong .scn)
        self.sign_X = float(rospy.get_param("~sign_X",  +1.0))
        self.sign_Y = float(rospy.get_param("~sign_Y",  +1.0))
        self.sign_R = float(rospy.get_param("~sign_R",  +1.0))
        # Với .scn của bạn: PWM dương làm ROV nổi -> để lệnh dương = LẶN, đặt sign_H = -1
        self.sign_H = float(rospy.get_param("~sign_H",  -1.0))

        # Trạng thái
        self.x = self.y = self.z = 0.0
        self.yaw = 0.0
        self.odom_ok = False

        self.phase = self.PHA_1_DESCEND
        self.depth_ok_since = None
        self.y_lock = None
        self.yaw_lock = None

        # I/O
        self.sub = rospy.Subscriber(self.odom_topic, Odometry, self.cb_odom, queue_size=1)
        self.pub = rospy.Publisher(f"/{self.veh}/setpoint/pwm", Float64MultiArray, queue_size=1)

        rospy.loginfo("BlueROV2 2-phase controller started for /%s", self.veh)
        rospy.loginfo("Phase 1 -> z=%.2f, then Phase 2 -> x=%.2f (straight), lock y & yaw", self.tz, self.tx)
        rospy.loginfo("Listening odometry on: %s", self.odom_topic)

    def cb_odom(self, msg: Odometry):
        p = msg.pose.pose.position
        q = msg.pose.pose.orientation
        self.x, self.y, self.z = p.x, p.y, p.z  # NED: z dương xuống
        _, _, yaw = euler_from_quaternion([q.x, q.y, q.z, q.w])
        self.yaw = yaw
        if not self.odom_ok:
            rospy.loginfo("First Odometry received: frame_id=%s, child_frame_id=%s",
                          getattr(msg.header, "frame_id", ""), getattr(msg, "child_frame_id", ""))
        self.odom_ok = True

    # ------- Mixer KHỚP .scn (KHÔNG tự invert; để .scn xử lý inverted_setpoint) -------
    def mix_to_thrusters(self, X, Y, R, H):
        """
        Áp dụng dấu logic sign_* rồi trộn theo thứ tự actuator trong .scn:
        1 FR, 2 FL, 3 BR, 4 BL, 5 DiveFR, 6 DiveFL, 7 DiveBR, 8 DiveBL
        """
        # Áp dụng dấu (cho phép lật nhanh bằng tham số)
        Xs = self.sign_X * X
        Ys = self.sign_Y * Y
        Rs = self.sign_R * R
        Hs = self.sign_H * H  # Với cấu hình của bạn: sign_H=-1 để lệnh dương => lặn

        # 4 thruster ngang
        T1 = +Xs - Ys - Rs   # FrontRight
        T2 = +Xs + Ys + Rs   # FrontLeft
        T3 = -Xs - Ys + Rs   # BackRight
        T4 = -Xs + Ys - Rs   # BackLeft

        # 4 thruster heave: tất cả CÙNG DẤU (inverted_setpoint đã có trong .scn)
        H5 = Hs   # DiveFrontRight  (inverted=false)
        H6 = Hs   # DiveFrontLeft   (inverted=true  -> .scn tự lật)
        H7 = Hs   # DiveBackRight   (inverted=true  -> .scn tự lật)
        H8 = Hs   # DiveBackLeft    (inverted=false)

        return [sat(v, -1.0, 1.0) for v in [T1, T2, T3, T4, H5, H6, H7, H8]]

    def spin(self):
        r = rospy.Rate(self.rate_hz)
        while not rospy.is_shutdown() and not self.odom_ok:
            rospy.loginfo_throttle(1.0, "Waiting for odometry ...")
            r.sleep()

        X_cmd = Y_cmd = R_cmd = H_cmd = 0.0

        while not rospy.is_shutdown():
            now = rospy.Time.now()

            # --------- PHA 1: CHỈ ĐI XUỐNG (HEAVE) ----------
            if self.phase == self.PHA_1_DESCEND:
                dz = (self.tz - self.z)  # NED: dz>0 -> đi xuống thêm
                X_cmd, Y_cmd, R_cmd = 0.0, 0.0, 0.0
                H_cmd = self.pid_z.step(dz, now)

                # Kiểm tra đạt độ sâu
                if abs(dz) <= self.z_tol:
                    if self.depth_ok_since is None:
                        self.depth_ok_since = now
                    elif (now - self.depth_ok_since).to_sec() >= self.hold_time:
                        self.y_lock = self.y
                        self.yaw_lock = self.yaw
                        self.pid_z.reset()
                        self.phase = self.PHA_2_CRUISE_X
                        rospy.loginfo("Switch to PHASE 2: lock y=%.3f, yaw=%.3f rad, target x=%.2f",
                                      self.y_lock, self.yaw_lock, self.tx)
                else:
                    self.depth_ok_since = None

            # --------- PHA 2: GIỮ Z, GIỮ YAW, CHẠY THEO X ----------
            if self.phase == self.PHA_2_CRUISE_X:
                dx = self.tx - self.x
                dz = self.tz - self.z

                # Giữ yaw tại yaw_lock
                e_yaw = wrap_pi(self.yaw_lock - self.yaw)
                R_cmd = sat(self.k_yaw * e_yaw, -self.r_max, self.r_max)

                # Khóa y = y_lock
                ey_world = self.y_lock - self.y
                # Chiếu sang hệ thân
                ex_body =  math.cos(self.yaw) * dx + math.sin(self.yaw) * ey_world
                ey_body = -math.sin(self.yaw) * dx + math.cos(self.yaw) * ey_world

                X_cmd = sat(self.k_v   * ex_body, -self.u_max, self.u_max)
                Y_cmd = sat(self.k_lat * ey_body, -self.u_max, self.u_max)
                H_cmd = self.pid_z.step(dz, now)

                # Giảm nhẹ khi gần đích x để dừng mượt
                if abs(dx) < 2.0:
                    scale = sat(abs(dx) / 2.0, 0.2, 1.0)
                    X_cmd *= scale
                    R_cmd *= scale

            # Slew limiter để lệnh mượt mà
            X = self.slew_X.step(X_cmd, now)
            Y = self.slew_Y.step(Y_cmd, now)
            R = self.slew_R.step(R_cmd, now)
            H = self.slew_H.step(H_cmd, now)

            cmd = self.mix_to_thrusters(X, Y, R, H)
            self.pub.publish(Float64MultiArray(data=cmd))
            r.sleep()

if __name__ == "__main__":
    try:
        BlueROV2Controller().spin()
    except rospy.ROSInterruptException:
        pass


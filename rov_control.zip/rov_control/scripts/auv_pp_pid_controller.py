#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os, math, datetime
import numpy as np
import rospy
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64MultiArray
from tf.transformations import euler_from_quaternion

# ---- vẽ không cần X server
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# --------------------- PID ---------------------
class PID:
    def __init__(self, Kp=0.0, Ki=0.0, Kd=0.0,
                 output_limits=(-1.0, 1.0), anti_windup=5.0):
        self.Kp, self.Ki, self.Kd = Kp, Ki, Kd
        self.min_out, self.max_out = output_limits
        self.i_max = anti_windup
        self.integral = 0.0
        self.prev_err = 0.0
        self.last_t = None
        

    def reset(self):
        self.integral = 0.0
        self.prev_err = 0.0
        self.last_t = None

    def step(self, err, now):
        if self.last_t is None:
            self.last_t = now
            self.prev_err = err
            return np.clip(self.Kp*err, self.min_out, self.max_out)
        dt = (now - self.last_t).to_sec()
        if dt <= 0.0:
            return np.clip(self.Kp*err + self.Ki*self.integral, self.min_out, self.max_out)
        self.integral += err*dt
        self.integral = np.clip(self.integral, -self.i_max, self.i_max)
        d = (err - self.prev_err)/dt
        u = self.Kp*err + self.Ki*self.integral + self.Kd*d
        self.prev_err = err
        self.last_t = now
        return np.clip(u, self.min_out, self.max_out)

# ----------------- Pure-Pursuit utils -----------------
def wrap_pi(a):
    while a > math.pi:  a -= 2*math.pi
    while a < -math.pi: a += 2*math.pi
    return a

def segment_proj(p, a, b):
    """project point p to segment a->b; return (proj, s, cte, tangent_unit, normal_unit, seg_len)"""
    ax, ay = a; bx, by = b; px, py = p
    vx, vy = bx-ax, by-ay
    L2 = vx*vx + vy*vy
    if L2 < 1e-8:
        t = 0.0; qx, qy = ax, ay
        tx, ty = 1.0, 0.0
    else:
        t = ((px-ax)*vx + (py-ay)*vy)/L2
        t = max(0.0, min(1.0, t))
        qx, qy = ax + t*vx, ay + t*vy
        norm = math.sqrt(vx*vx + vy*vy) + 1e-9
        tx, ty = vx/norm, vy/norm
    nx, ny = -ty, tx
    dx, dy = px-qx, py-qy
    cte = dx*nx + dy*ny  # signed cross-track (trái dương)
    seg_len = math.sqrt(L2)
    return (qx, qy), t, cte, (tx, ty), (nx, ny), seg_len

# --------------- Main Controller Node ---------------
class Node:
    def __init__(self):
        rospy.init_node("girona500_pp_pid_controller")

        # ---- Params ----
        self.robot_name  = rospy.get_param("~robot_name", "GIRONA500")
        self.save_dir    = os.path.expanduser(rospy.get_param("~save_dir", "~/.ros"))

        # Stonefish NED: z dương xuống
        self.z_is_down   = rospy.get_param("~z_is_down", True)


        self.surge_sign  = rospy.get_param("~surge_sign", -1.0)    
        self.sway_sign   = rospy.get_param("~sway_sign",  -1.0)
        self.heave_sign  = rospy.get_param("~heave_sign", -1.0)
        self.yaw_sign    = rospy.get_param("~yaw_sign",   1.0)

        # FF để thắng lực nổi (âm = đẩy xuống)
        self.heave_bias  = rospy.get_param("~heave_bias", -0.18)

        # -------- Pure Pursuit (giảm vồng góc) --------
        self.Ld_min = rospy.get_param("~Ld_min", 1.6)              
        self.Ld_max = rospy.get_param("~Ld_max", 3.8)              
        self.k_Ld   = rospy.get_param("~k_Ld",   1.75)              
        self.switch_radius = rospy.get_param("~switch_radius", 1.4)
        
        # ----- Corner anticipation (blend 2 đoạn) -----
        self.corner_enable   = rospy.get_param("~corner_enable", True)
        self.corner_deg_min  = rospy.get_param("~corner_deg_min", 15.0)   # chỉ kích hoạt nếu > 15°
        self.corner_gain     = rospy.get_param("~corner_gain", 1.0)       # 0..1, mức trộn hướng
        self.corner_slow_max = rospy.get_param("~corner_slow_max", 0.45)  # giảm Uref tối đa 45% ở sát góc
        self.corner_ld_shrink= rospy.get_param("~corner_ld_shrink", 0.40) # rút Ld tối đa 40% ở sát góc


        # tốc độ theo độ cong (chậm lại khi vào cua)
        self.U_nom  = rospy.get_param("~U_nom", 0.55)
        self.U_min  = rospy.get_param("~U_min", 0.20)
        self.k_slow = rospy.get_param("~k_slow", 3.0)

        # -------- PID gains (theo 3 đồ thị) --------
        self.pid_yaw   = PID(Kp=1.9,  Ki=0.00, Kd=0.5, output_limits=(-0.85, 0.85))
        self.pid_cte   = PID(Kp=0.6, Ki=0.01, Kd=0.15, output_limits=(-0.85, 0.85))
        self.pid_surge = PID(Kp=0.60, Ki=0.00, Kd=0.12, output_limits=(-0.9, 0.9))
        self.pid_heave = PID(Kp=0.80, Ki=0.06, Kd=1.10, output_limits=(-0.9, 0.9), anti_windup=0.5)

        # ---------------- Speed governor theo độ cong ----------------
        self.U_max     = rospy.get_param("~U_max", 0.55)   # trần tốc
        self.a_lat_max = rospy.get_param("~a_lat_max", 0.16)  # m/s^2, gia tốc ngang cho phép
        self.U_alpha   = rospy.get_param("~U_alpha", 0.5)  # 0..1, lọc thấp thông cho Uref
        self.kappa_eps = 1e-3
        self.Uref_filt = self.U_min



        # Waypoints (x,y,z_depth) – NED depth (dương xuống)
        self.waypoints = rospy.get_param("~waypoints", [
            [10.0,  0.0, 15.0],
            [10.0, 10.0, 15.0],
            [ 0.0, 10.0, 15.0],
            [ 0.0,  0.0, 15.0],
            [ 0.0,  0.0,  2.0],
        ])

        # state
        self.px = self.py = self.pz = 0.0
        self.yaw = 0.0
        self.ux = self.uy = 0.0
        self.have_odom = False
        self.seg_i = 0  # current segment index

        # log để vẽ
        self.t0 = None
        self.log = []  # mỗi mẫu: (t, x, y, z, x_ref, y_ref, z_ref, seg, cte, Ld, kappa, Uref)

        # ROS I/O
        self.pub_thr = rospy.Publisher(f"/{self.robot_name}/thruster_setpoints",
                                       Float64MultiArray, queue_size=1)
        rospy.Subscriber(f"/{self.robot_name}/dynamics", Odometry, self.cb_odom)

        rospy.loginfo("AUV GIRONA500 PP+PID controller ready.")
        self.wait_odom()

    def wait_odom(self):
        rospy.loginfo("Đợi Odometry...")
        r = rospy.Rate(50)
        while not rospy.is_shutdown() and not self.have_odom:
            r.sleep()
        rospy.loginfo("Đã nhận Odometry đầu tiên.")

    def cb_odom(self, msg):
        self.px = msg.pose.pose.position.x
        self.py = msg.pose.pose.position.y
        self.pz = msg.pose.pose.position.z  # NED (dương xuống)

        q = msg.pose.pose.orientation
        _, _, yaw = euler_from_quaternion([q.x, q.y, q.z, q.w])
        self.yaw = yaw

        self.ux = msg.twist.twist.linear.x
        self.uy = msg.twist.twist.linear.y

        if not self.have_odom:
            self.have_odom = True
            self.t0 = rospy.Time.now()

    # ---------------- allocation & publish ----------------
    def send(self, surge_cmd, sway_cmd, heave_cmd, yaw_cmd):
        """
        Layout 5 thruster:
          [SurgePort, SurgeStarboard, HeaveBow, HeaveStern, Sway]
        Tất cả clamp [-1,1] (normalized_setpoint="true" trong .scn)
        """
        k_yaw_mix = 1.0
        # đảo dấu theo tham số sign
        surge_cmd *= self.surge_sign
        sway_cmd  *= self.sway_sign
        # heave_sign áp dụng khi tính heave (dưới)

        sp = np.clip(surge_cmd - k_yaw_mix*self.yaw_sign*yaw_cmd, -1.0, 1.0)
        ss = np.clip(surge_cmd + k_yaw_mix*self.yaw_sign*yaw_cmd, -1.0, 1.0)
        hb = np.clip(heave_cmd, -1.0, 1.0)
        hs = np.clip(heave_cmd, -1.0, 1.0)
        sy = np.clip(sway_cmd,  -1.0, 1.0)

        msg = Float64MultiArray()
        msg.data = [float(sp), float(ss), float(hb), float(hs), float(sy)]
        self.pub_thr.publish(msg)

    # --------------- plotting ---------------
    def save_plots(self):
        if not self.log:
            rospy.logwarn("Không có log để vẽ.")
            return []

        os.makedirs(self.save_dir, exist_ok=True)
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        base = os.path.join(self.save_dir, f"auv_pp_pid_{ts}")

        arr = np.array(self.log)
        t     = arr[:,0]
        x     = arr[:,1]; y = arr[:,2]; z = arr[:,3]
        xref  = arr[:,4]; yref = arr[:,5]; zref = arr[:,6]
        cte   = arr[:,8]

        # --- Hình 1: XY (Top-down) ---
        plt.figure(figsize=(7,6))
        # đường tham chiếu từ các waypoint
        wps = np.array(self.waypoints)
        plt.plot(wps[:,0], wps[:,1], 'k--', lw=1.5, label='Reference path (WP)')
        plt.scatter(wps[:,0], wps[:,1], c='k', s=25)
        # quỹ đạo thực
        plt.plot(x, y, label='AUV trajectory')
        # điểm lookahead/ref theo thời gian
        plt.plot(xref, yref, alpha=0.6, label='Lookahead (ref)')
        plt.axis('equal')
        plt.xlabel('X [m]'); plt.ylabel('Y [m]')
        plt.title('Top view (XY)')
        plt.grid(True, ls=':')
        plt.legend()
        f1 = base + "_xy.png"
        plt.savefig(f1, dpi=150); plt.close()

        # --- Hình 2: Z (độ sâu) theo thời gian ---
        plt.figure(figsize=(8,4))
        plt.plot(t, z, label='Depth z (meas)')
        plt.plot(t, zref, label='Depth z_ref (from segment B)', alpha=0.8)
        plt.xlabel('Time [s]')
        plt.ylabel('Depth z (NED, +down) [m]')
        plt.title('Depth tracking')
        plt.grid(True, ls=':')
        plt.legend()
        f2 = base + "_depth.png"
        plt.savefig(f2, dpi=150); plt.close()

        # --- Hình 3: CTE theo thời gian ---
        plt.figure(figsize=(8,4))
        plt.plot(t, cte)
        plt.xlabel('Time [s]')
        plt.ylabel('CTE [m]')
        plt.title('Cross-Track Error')
        plt.grid(True, ls=':')
        f3 = base + "_cte.png"
        plt.savefig(f3, dpi=150); plt.close()

        rospy.loginfo("Đã lưu hình: %s, %s, %s", f1, f2, f3)
        return [f1, f2, f3]

    # --------------- controller core ---------------
    def run(self):
        rate = rospy.Rate(20)

        rospy.loginfo("Bắt đầu bám quỹ đạo: %d điểm.", len(self.waypoints))
        for k in range(len(self.waypoints)-1):
            rospy.loginfo("→ Segment %d: %s → %s", k+1, self.waypoints[k], self.waypoints[k+1])

        while not rospy.is_shutdown() and self.seg_i < len(self.waypoints)-1:
            now = rospy.Time.now()

            A = self.waypoints[self.seg_i]
            B = self.waypoints[self.seg_i+1]

            (qx,qy), s, cte, (tx,ty), (nx,ny), seg_len = segment_proj(
                (self.px, self.py), (A[0],A[1]), (B[0],B[1])
            )

            # switch segment khi đã gần B
            dist_end = math.hypot(B[0]-self.px, B[1]-self.py)
            if dist_end < self.switch_radius:
                self.seg_i += 1
                self.pid_cte.reset()
                self.pid_yaw.reset()
                self.pid_surge.reset()
                if self.seg_i >= len(self.waypoints)-1:
                    break
                continue

                        # --- Lookahead động cơ bản ---
            u = math.hypot(self.ux, self.uy)
            Ld = float(np.clip(self.Ld_min + self.k_Ld * u, self.Ld_min, self.Ld_max))

            # Dựng điểm lookahead mặc định trên đoạn A->B
            s_la = (s * seg_len + Ld) / max(seg_len, 1e-6)
            s_la = min(1.0, s_la)
            x_ref = A[0] + (B[0] - A[0]) * s_la
            y_ref = A[1] + (B[1] - A[1]) * s_la

            # --- Nếu sắp vào góc: blend hướng 2 đoạn để bẻ lái sớm ---
            w_corner = 0.0
            if self.corner_enable and (self.seg_i < len(self.waypoints) - 2):
                # tiếp tuyến đoạn hiện tại t1
                t1x, t1y = tx, ty

                # tiếp tuyến đoạn kế tiếp t2
                C = self.waypoints[self.seg_i + 2]
                v2x, v2y = (C[0] - B[0]), (C[1] - B[1])
                n2 = math.hypot(v2x, v2y) + 1e-9
                t2x, t2y = v2x / n2, v2y / n2

                # góc giữa hai đoạn
                dot = max(-1.0, min(1.0, t1x * t2x + t1y * t2y))
                theta = math.degrees(math.acos(dot))  # 0..180

                if theta >= self.corner_deg_min:
                    # khoảng cách còn lại tới waypoint B
                    dist_end = math.hypot(B[0] - self.px, B[1] - self.py)

                    # bán kính tối thiểu theo ràng buộc gia tốc ngang
                    Rmin = max(u * u / max(self.a_lat_max, 1e-6), 0.5)

                    # “vùng góc” cần chuẩn bị: phụ thuộc Ld và hình học góc
                    d_corner = 0.5 * Ld + Rmin * math.tan(math.radians(theta) / 2.0)

                    # trọng số trộn 0..1 tăng dần khi tiến vào góc
                    w_corner = float(np.clip(1.0 - dist_end / max(d_corner, 1e-6), 0.0, 1.0))
                    w_corner *= self.corner_gain

                    if w_corner > 0.0:
                        # rút Ld và giảm tốc khi sát góc
                        Ld_eff = Ld * (1.0 - self.corner_ld_shrink * w_corner)
                        Ld_eff = float(np.clip(Ld_eff, 0.5 * self.Ld_min, self.Ld_max))

                        # tiếp tuyến trộn
                        tbx = (1.0 - w_corner) * t1x + w_corner * t2x
                        tby = (1.0 - w_corner) * t1y + w_corner * t2y
                        norm_tb = math.hypot(tbx, tby) + 1e-9
                        tbx, tby = tbx / norm_tb, tby / norm_tb

                        # điểm đuổi mới: đi theo tiếp tuyến trộn từ vị trí hiện tại
                        x_ref = self.px + tbx * Ld_eff
                        y_ref = self.py + tby * Ld_eff
                        Ld = Ld_eff  # dùng Ld đã rút

            # --- Tính α, κ và bộ hạn tốc theo gia tốc ngang ---
            alpha = wrap_pi(math.atan2(y_ref - self.py, x_ref - self.px) - self.yaw)
            kappa = (2.0 * math.sin(alpha)) / max(Ld, 1e-3)
            
            # Sai số hướng cho PID yaw (alpha đã là yaw_ref - yaw)
            e_yaw = alpha
            yaw_cmd = self.pid_yaw.step(e_yaw, now)


            U_cap = math.sqrt(max(self.a_lat_max, 1e-6) / max(abs(kappa), self.kappa_eps))
            Uref_des = float(np.clip(U_cap, self.U_min, self.U_max))

            # nếu sắp vào góc, phạt thêm tốc độ để ôm cua mượt
            if w_corner > 0.0:
                Uref_des *= (1.0 - self.corner_slow_max * w_corner)

            # lọc thấp thông
            self.Uref_filt = self.U_alpha * self.Uref_filt + (1.0 - self.U_alpha) * Uref_des
            Uref = self.Uref_filt


            # SURGE theo trục thân + bù sai số tới lookahead
            ex_b  =  (x_ref - self.px)*math.cos(self.yaw) + (y_ref - self.py)*math.sin(self.yaw)
            surge = self.pid_surge.step(ex_b, now)
            surge = np.clip(0.45*Uref + 0.55*surge, -0.9, 0.9)

            # SWAY theo CTE (trái dương) – sẽ nhân sway_sign trong send()
            sway  = self.pid_cte.step(cte, now)

            # YAW PID
            yaw_cmd = self.pid_yaw.step(e_yaw, now)

            # HEAVE PID theo độ sâu đích của đoạn B (NED: z dương xuống)
            z_meas = self.pz if self.z_is_down else -self.pz
            z_ref  = B[2]
            ez     = z_ref - z_meas
            heave  = self.heave_sign*self.pid_heave.step(ez, now) + self.heave_bias
            heave  = float(np.clip(heave, -1.0, 1.0))

            # Xuất lệnh
            self.send(float(surge), float(sway), float(heave), float(yaw_cmd))

            # --- LOG + in kèm target ---
            tsec = (now - self.t0).to_sec() if self.t0 is not None else 0.0
            self.log.append([tsec, self.px, self.py, z_meas, x_ref, y_ref, z_ref,
                             self.seg_i, cte, Ld, kappa, Uref])

            rospy.loginfo_throttle(0.7,
                ("Seg %d | Pos x=%.2f y=%.2f z=%.2f | tgtLA x=%.2f y=%.2f | goal x=%.2f y=%.2f z=%.2f | "
                 "u≈%.02f Ld=%.2f cte=%.2f kappa=%.3f Uref=%.2f | angErr=%.1f° | cmd(su=%.2f, sw=%.2f, hv=%.2f, yw=%.2f)"),
                self.seg_i+1, self.px, self.py, z_meas,
                x_ref, y_ref, B[0], B[1], z_ref,
                u, Ld, cte, kappa, Uref, math.degrees(e_yaw),
                surge, sway, heave, yaw_cmd
            )

            rate.sleep()

        # stop
        self.send(0,0,0,0)
        rospy.loginfo("Hoàn thành quỹ đạo.")
        self.save_plots()

if __name__ == "__main__":
    try:
        Node().run()
    except rospy.ROSInterruptException:
        pass


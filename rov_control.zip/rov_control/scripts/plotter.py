#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from datetime import datetime

def save_and_plot_trajectory(log_data, waypoints, robot_name="ROV"):
    """
    Lưu dữ liệu log và vẽ các biểu đồ quỹ đạo 3D và sai số.
    Hàm này được thiết kế để chạy độc lập.
    """
    if not log_data:
        print("Cảnh báo: Không có dữ liệu để vẽ biểu đồ.")
        return

    # --- Chuẩn bị dữ liệu và đường dẫn file ---
    data = np.array(log_data)
    out_dir = os.path.expanduser("~/.ros")

    # Thêm timestamp vào tên file để không bị ghi đè
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    # --- 1. Vẽ biểu đồ quỹ đạo 3D ---
    fig = plt.figure(figsize=(10, 10))
    ax = fig.add_subplot(111, projection='3d')
    ax.plot(data[:, 1], data[:, 2], data[:, 3], label=f'{robot_name} Trajectory', linewidth=2)
    ax.plot(waypoints[:, 0], waypoints[:, 1], waypoints[:, 2], 'ro--', label='Waypoints')
    ax.scatter(data[0, 1], data[0, 2], data[0, 3], color='g', s=100, label='Start Point', depthshade=True)
    ax.set_xlabel('X [m]'); ax.set_ylabel('Y [m]'); ax.set_zlabel('Z (Depth) [m]')
    ax.set_title(f'3D Trajectory Following - {robot_name}'); ax.legend(); ax.grid(True)
    ax.invert_zaxis()

    path_3d = os.path.join(out_dir, f"trajectory_3d_{timestamp}.png")
    plt.savefig(path_3d)
    plt.close(fig)
    print(f"Đã lưu biểu đồ quỹ đạo 3D vào: {path_3d}")

    # --- 2. Vẽ biểu đồ sai số theo thời gian ---
    fig, axs = plt.subplots(4, 1, figsize=(12, 15), sharex=True)

    axs[0].plot(data[:, 0], data[:, 5], label='X Error'); axs[0].set_ylabel('X Error [m]'); axs[0].grid(True); axs[0].legend()
    axs[1].plot(data[:, 0], data[:, 6], label='Y Error'); axs[1].set_ylabel('Y Error [m]'); axs[1].grid(True); axs[1].legend()
    axs[2].plot(data[:, 0], data[:, 7], label='Z Error'); axs[2].set_ylabel('Z Error (Depth) [m]'); axs[2].grid(True); axs[2].legend()
    axs[3].plot(data[:, 0], np.rad2deg(data[:, 8]), label='Yaw Error'); axs[3].set_ylabel('Yaw Error [deg]'); axs[3].grid(True); axs[3].legend()

    axs[3].set_xlabel('Time [s]')
    fig.suptitle('PID Controller Errors vs. Time', fontsize=16)
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])

    path_errors = os.path.join(out_dir, f"pid_errors_{timestamp}.png")
    plt.savefig(path_errors)
    plt.close(fig)
    print(f"Đã lưu biểu đồ sai số điều khiển vào: {path_errors}")

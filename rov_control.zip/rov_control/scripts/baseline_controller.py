#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import math
import numpy as np
import rospy
from std_msgs.msg import Float64MultiArray
from nav_msgs.msg import Odometry
from tf.transformations import euler_from_quaternion

from plotter import save_and_plot_trajectory  # giữ nguyên nếu bạn đang dùng

# =========================================================
#  PID đơn giản cho trục Z (heave) – giữ nguyên như bạn
# =========================================================
class PID:
    def __init__(self, Kp, Ki, Kd, out_lim=(-1.0, 1.0), i_lim=0.8):
        self.Kp, self.Ki, self.Kd = Kp, Ki, Kd
        self.out_lim = out_lim
        self.i_lim = i_lim
        self.e_prev = 0.0
        self.i = 0.0
        self.t_prev = None

    def reset(self):
        self.e_prev = 0.0
        self.i = 0.0
        self.t_prev = None

    def step(self, e, t_now):
        if self.t_prev is None:
            self.t_prev = t_now
            return 0.0
        dt = (t_now - self.t_prev).to_sec()
        if dt <= 0.0:
            return 0.0
        self.i = np.clip(self.i + e*dt, -self.i_lim, self.i_lim)
        d = (e - self.e_prev)/dt
        u = self.Kp*e + self.Ki*self.i + self.Kd*d
        u = np.clip(u, self.out_lim[0], self.out_lim[1])
        self.e_prev = e
        self.t_prev = t_now
        return u

# =========================================================
#  Controller chính: Pure Pursuit (guidance) + PID (control)
# =========================================================
class ROV_PP_PID:
    def __init__(self):
        rospy.init_node("rov_pp_pid_controller")

        # ================== Params ==================
        self.robot_name = rospy.get_param("~robot_name", "GIRONA500")

        # Waypoints (X, Y, Z) – bạn đổi tùy ý
        self.waypoints = rospy.get_param("~waypoints",
            [[10.0, 0.0, 15.0],
             [10.0,10.0, 15.0],
             [ 0.0,10.0, 15.0],
             [ 0.0, 0.0, 15.0],
             [ 0.0, 0.0,  2.0]]
        )
        self.waypoints = [tuple(w) for w in self.waypoints]

        # Pure Pursuit params (đã chọn an toàn & dễ tune)
        self.U_MAX   = 0.9      # "tốc độ" mong muốn (đơn vị sau khi qua mixer, ~PWM norm)
        self.U_MIN   = 0.2
        self.A_LAT   = 0.25     # gia tốc ngang mục tiêu (để schedule speed) – dùng dạng tuyến tính đơn giản
        self.L0      = 3.0      # look-ahead cơ sở [m]
        self.L_MIN   = 1.0
        self.L_MAX   = 8.0
        self.kU      = 1.2      # tăng Ld theo tốc độ ước lượng
        self.k_kappa = 1.0      # giảm tốc theo độ cong

        # PID yaw (PI đủ dùng) – dùng rời, không xài lớp PID trên cho dễ kiểm soát dấu
        self.Kp_psi  = 1.0
        self.Ki_psi  = 0.25
        self.R_MAX   = 0.7      # [rad/s] giới hạn yaw-rate sau khi cộng r_ff
        self.int_psi = 0.0
        self.int_lim = 0.7

        # PID heave (giữ độ sâu)
        self.pid_heave = PID(Kp=1.0, Ki=0.10, Kd=0.5, out_lim=(-1.0,1.0), i_lim=0.8)

        # Thành phần P cho surge (tiến thẳng theo LOS)
        self.Kp_surge = 0.35    # tác động lên lệnh tiến; đã có schedule theo độ cong

        # Trạng thái
        self.pose = dict(x=0.0, y=0.0, z=0.0, yaw=0.0)
        self.odom_ok = False

        # ước lượng tốc độ phẳng (m/s) từ vi phân vị trí – low-pass
        self.U_hat   = 0.0
        self.prev_xy = None
        self.prev_t  = None
        self.alpha_U = 0.2  # LPF

        # Log
        self.log_data = []
        self.start_time = rospy.Time.now()

        # ROS I/O
        self.pub_thr = rospy.Publisher(f'/{self.robot_name}/thruster_setpoints',
                                       Float64MultiArray, queue_size=1)
        self.sub_odom = rospy.Subscriber(f'/{self.robot_name}/dynamics',
                                         Odometry, self.cb_odom)

        rospy.loginfo("ROV PP+PID Controller ready. Waiting odom...")
        self.wait_odom()

    # ---------------- helpers ----------------
    def wait_odom(self):
        r = rospy.Rate(20)
        while not self.odom_ok and not rospy.is_shutdown():
            r.sleep()
        rospy.loginfo("Odometry OK.")

    def cb_odom(self, msg: Odometry):
        p = msg.pose.pose.position
        q = msg.pose.pose.orientation
        _, _, yaw = euler_from_quaternion([q.x,q.y,q.z,q.w])

        self.pose['x'] = p.x
        self.pose['y'] = p.y
        self.pose['z'] = p.z
        self.pose['yaw'] = yaw
        self.odom_ok = True

        # Ước lượng U (tốc độ phẳng) từ vi phân
        now = msg.header.stamp if msg.header.stamp != rospy.Time() else rospy.Time.now()
        xy  = np.array([p.x, p.y])
        if self.prev_xy is not None and self.prev_t is not None:
            dt = (now - self.prev_t).to_sec()
            if dt > 1e-3:
                v = np.linalg.norm(xy - self.prev_xy) / dt
                self.U_hat = (1-self.alpha_U)*self.U_hat + self.alpha_U*v
        self.prev_xy = xy
        self.prev_t  = now

    @staticmethod
    def wrap(angle):
        a = (angle + math.pi) % (2*math.pi) - math.pi
        return a

    # Hình học: chiếu P lên đoạn AB và lấy điểm cách P một đoạn Ld dọc theo AB
    def pick_lookahead(self, P, A, B, Ld):
        AB = B - A
        n  = np.linalg.norm(AB) + 1e-9
        ab = AB / n
        # chiếu & kẹp lên đoạn
        t = np.dot(P - A, AB) / (n*n)
        t = np.clip(t, 0.0, 1.0)
        Q = A + t*AB
        PL = Q + ab*Ld   # tiến lên thêm Ld
        # nhưng không vượt quá B nhiều, để bám mượt khi sắp hết đoạn
        if np.dot(PL - B, ab) > 0.0:
            PL = B.copy()
        return PL, t

    # Gửi lệnh lực về mixer (giữ đúng thứ tự bạn đang dùng)
    def send_cmd(self, surge, sway, heave, yaw_rate):
        # dấu đảo giống code gốc
        surge_cmd = -surge
        sway_cmd  = -sway
        heave_cmd = -heave
        yaw_cmd   = -yaw_rate

        surge_port      = np.clip(surge_cmd - yaw_cmd, -1.0, 1.0)
        surge_starboard = np.clip(surge_cmd + yaw_cmd, -1.0, 1.0)

        arr = [surge_port, surge_starboard, heave_cmd, heave_cmd, sway_cmd]
        m = Float64MultiArray(); m.data = arr
        self.pub_thr.publish(m)

    # ---------------- main loop ----------------
    def run(self):
        rate = rospy.Rate(20)
        seg = 0
        rospy.loginfo("Start trajectory (PP + PID).")

        while not rospy.is_shutdown() and seg < len(self.waypoints):
            # xác định 2 điểm A->B của đoạn hiện tại
            if seg == 0:
                A = np.array([self.waypoints[0][0], self.waypoints[0][1]])
                z_d = self.waypoints[0][2]
            else:
                A = np.array([self.waypoints[seg-1][0], self.waypoints[seg-1][1]])
                z_d = self.waypoints[seg][2]   # đổi độ sâu theo waypoint hiện tại
            B = np.array([self.waypoints[seg][0], self.waypoints[seg][1]])

            P = np.array([self.pose['x'], self.pose['y']])
            yaw = self.pose['yaw']
            now = rospy.Time.now()

            # Look-ahead động
            Ld = np.clip(self.L0 + self.kU*self.U_hat, self.L_MIN, self.L_MAX)
            PL, _ = self.pick_lookahead(P, A, B, Ld)
            d = PL - P
            dist_PL = float(np.linalg.norm(d))
            chi_d = math.atan2(d[1], d[0])  # heading mong muốn

            # Lỗi hướng
            epsi = self.wrap(chi_d - yaw)

            # Độ cong & yaw-rate feed-forward
            kappa = 2.0*math.sin(epsi)/(Ld + 1e-6)
            r_ff  = self.U_hat * kappa

            # Speed scheduling theo độ cong (giảm tốc khi cua gắt)
            speed_factor = np.clip(1.0 - self.k_kappa*abs(kappa), self.U_MIN/self.U_MAX, 1.0)

            # Surge command: theo LOS (dựng theo chi_d), scale bởi speed_factor
            # khoảng cách theo phương LOS:
            e_forward = d[0]*math.cos(chi_d) + d[1]*math.sin(chi_d)
            surge_cmd = np.clip(self.Kp_surge * e_forward, -self.U_MAX, self.U_MAX)
            surge_cmd *= speed_factor

            # Heave PID
            e_z = z_d - self.pose['z']
            heave_cmd = self.pid_heave.step(e_z, now)

            # Yaw PI + feed-forward (anti-windup đơn giản)
            self.int_psi = np.clip(self.int_psi + epsi*(1.0/20.0), -self.int_lim, self.int_lim)
            r_pid = self.Kp_psi*epsi + self.Ki_psi*self.int_psi
            yaw_rate_cmd = np.clip(r_ff + r_pid, -self.R_MAX, self.R_MAX)
            if abs(yaw_rate_cmd) >= self.R_MAX:
                # chống windup
                self.int_psi -= epsi*(1.0/20.0)*0.5

            # Gửi lệnh
            self.send_cmd(surge_cmd, 0.0, heave_cmd, yaw_rate_cmd)

            # Chuyển đoạn khi đủ gần B
            dist_B = float(np.linalg.norm(B - P))
            if dist_B < 0.7:   # ngưỡng tới waypoint
                seg += 1
                rospy.loginfo(f"Reached waypoint {seg}/{len(self.waypoints)}")
                # reset tích phân yaw cho đoạn mới
                self.int_psi = 0.0

            # Log
            tlog = (now - self.start_time).to_sec()
            self.log_data.append((tlog, self.pose['x'], self.pose['y'], self.pose['z'],
                                  self.pose['yaw'], e_forward, e_z, epsi,
                                  float(Ld), float(self.U_hat), float(kappa)))

            # debug nhẹ
            rospy.loginfo_throttle(0.5,
                f"XY=({self.pose['x']:.1f},{self.pose['y']:.1f}) Z={self.pose['z']:.1f} "
                f"χd={math.degrees(chi_d):.1f}° eψ={math.degrees(epsi):.1f}° "
                f"Û={self.U_hat:.2f} Ld={Ld:.1f} κ={kappa:.3f} "
                f"surge={surge_cmd:.2f} yaẇ={yaw_rate_cmd:.2f}")

            rate.sleep()

        # dừng
        self.send_cmd(0,0,0,0)
        rospy.loginfo("Done path.")

        # Vẽ & lưu (nếu bạn có plotter)
        try:
            wps_np = np.array(self.waypoints, dtype=float)
            save_and_plot_trajectory(self.log_data, wps_np, self.robot_name)
        except Exception as e:
            rospy.logwarn(f"Plot skipped: {e}")

# =========================================================
if __name__ == "__main__":
    try:
        ctrl = ROV_PP_PID()
        ctrl.run()
    except rospy.ROSInterruptException:
        pass


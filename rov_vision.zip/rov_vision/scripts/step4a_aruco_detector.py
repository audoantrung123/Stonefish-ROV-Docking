#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
import numpy as np
import cv2
from cv_bridge import CvBridge
from sensor_msgs.msg import Image, CameraInfo
from geometry_msgs.msg import PoseStamped, PointStamped
from std_msgs.msg import Float32
import tf2_ros
import tf2_geometry_msgs  # chỉ cần để Buffer.transform hoạt động với PointStamped
from tf2_geometry_msgs.tf2_geometry_msgs import do_transform_pose


# -------- DICTIONARY MAP --------
DICT_MAP = {
    "DICT_4X4_50":  cv2.aruco.DICT_4X4_50,
    "DICT_4X4_100": cv2.aruco.DICT_4X4_100,
    "DICT_5X5_50":  cv2.aruco.DICT_5X5_50,
    "DICT_6X6_50":  cv2.aruco.DICT_6X6_50,
    # có thể không có trong một số bản OpenCV -> fallback về 4X4
    "DICT_APRILTAG_36h11": getattr(cv2.aruco, "DICT_APRILTAG_36h11", cv2.aruco.DICT_4X4_50),
}

def _make_detector_params():
    """Tạo DetectorParameters, tương thích nhiều phiên bản OpenCV."""
    if hasattr(cv2.aruco, "DetectorParameters"):
        params = cv2.aruco.DetectorParameters()
    else:
        params = cv2.aruco.DetectorParameters_create()

    # --- các tham số được nới lỏng cho môi trường nước (nhiễu/đục) ---
    params.adaptiveThreshWinSizeMin = 3
    params.adaptiveThreshWinSizeMax = 53
    params.adaptiveThreshWinSizeStep = 4
    params.adaptiveThreshConstant   = 7

    params.minMarkerPerimeterRate   = 0.02
    params.maxMarkerPerimeterRate   = 4.0
    params.polygonalApproxAccuracyRate = 0.03
    params.minCornerDistanceRate    = 0.02

    # tinh chỉnh góc
    if hasattr(params, "cornerRefinementMethod"):
        params.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX

    # cho phép phát hiện marker đảo màu (đôi khi ánh sáng làm đảo đen/trắng)
    if hasattr(params, "detectInvertedMarker"):
        params.detectInvertedMarker = True

    # bù méo phối cảnh mạnh khi nhìn xiên
    if hasattr(params, "perspectiveRemovePixelPerCell"):
        params.perspectiveRemovePixelPerCell = 4
    if hasattr(params, "perspectiveRemoveIgnoredMarginPerCell"):
        params.perspectiveRemoveIgnoredMarginPerCell = 0.33

    return params


class ArucoDetector(object):
    def __init__(self):
        rospy.init_node("aruco_detector")

        # -------- THAM SỐ ROS --------
        self.image_topic       = rospy.get_param("~image_topic", "/camera/image_raw")
        self.camera_info_topic = rospy.get_param("~camera_info_topic", "/camera/image_raw/camera_info")
        dict_name              = rospy.get_param("~dictionary", "DICT_4X4_50")
        self.marker_length     = float(rospy.get_param("~marker_length", 0.20))   # m (cạnh mã)
        self.axis_len          = float(rospy.get_param("~axis_len", 0.15))        # m (vẽ trục)
        self.hfov_deg          = float(rospy.get_param("~horizontal_fov_deg", 55.0))  # fallback khi thiếu CameraInfo

        # tiền xử lý ảnh
        self.use_clahe         = bool(rospy.get_param("~use_clahe", True))
        self.clahe_clip        = float(rospy.get_param("~clahe_clip", 3.0))
        self.clahe_tiles       = int(rospy.get_param("~clahe_tiles", 8))
        self.median_ksize      = int(rospy.get_param("~median_ksize", 3))

        self.bridge = CvBridge()

        # camera intrinsics
        self.K = None
        self.D = None
        self.have_caminfo = False
        
        # Publish pose đã đổi sang frame Vehicle
        self.pub_pose_vehicle = rospy.Publisher(
            "/dock/pose_vehicle", PoseStamped, queue_size=1
        )

        # Dùng TF mặc định để đổi pose về Vehicle
        self.use_tf = rospy.get_param("~use_tf", True)
        self.target_frame = rospy.get_param("~target_frame", "Vehicle")
        if self.use_tf:
            self.tfbuf = tf2_ros.Buffer()
            self.tfl = tf2_ros.TransformListener(self.tfbuf)


        # === Step 5: target point cho controller ===
        self.target_frame = rospy.get_param("~target_frame", "")   # ví dụ "map"/"ned"; "" = giữ frame ảnh (camera)
        self.use_tf       = rospy.get_param("~use_tf", False)

        self.pub_target = rospy.Publisher(
            "/rov_vision/target_point", PointStamped, queue_size=1
        )
        self.pub_range = rospy.Publisher(
            "/rov_vision/target_distance", Float32, queue_size=1
        )

        if self.use_tf:
            self.tfbuf = tf2_ros.Buffer()
            self.tfl   = tf2_ros.TransformListener(self.tfbuf)
            
        # -------- TẠO DETECTOR --------
        aruco_dict = cv2.aruco.getPredefinedDictionary(
            DICT_MAP.get(dict_name, cv2.aruco.DICT_4X4_50)
        )
        params = _make_detector_params()

        if hasattr(cv2.aruco, "ArucoDetector"):
            self.detector = cv2.aruco.ArucoDetector(aruco_dict, params)
            self._use_new_api = True
        else:
            self.detector = (aruco_dict, params)
            self._use_new_api = False

        # -------- PUB/SUB --------
        self.pub_dbg  = rospy.Publisher("aruco/debug_image", Image, queue_size=1)
        self.pub_pose = rospy.Publisher("aruco/pose",       PoseStamped, queue_size=1)

        rospy.Subscriber(self.camera_info_topic, CameraInfo, self.cb_caminfo, queue_size=1)
        rospy.Subscriber(self.image_topic,       Image,      self.cb_image,   queue_size=1)

        rospy.loginfo("Step4A | img=%s | caminfo=%s | dict=%s | marker=%.2fm | api=%s",
                      self.image_topic, self.camera_info_topic, dict_name,
                      self.marker_length, "new" if self._use_new_api else "legacy")

    # -------- CALLBACKS --------
    def cb_caminfo(self, msg: CameraInfo):
        self.K = np.array(msg.K, dtype=np.float64).reshape(3, 3)
        self.D = np.array(msg.D, dtype=np.float64).reshape(-1, 1)  # (N,1)
        if not self.have_caminfo:
            self.have_caminfo = True
            rospy.loginfo("CameraInfo: %dx%d | fx=%.1f fy=%.1f cx=%.1f cy=%.1f | D=%s",
                          msg.width, msg.height,
                          self.K[0,0], self.K[1,1], self.K[0,2], self.K[1,2],
                          np.array2string(self.D.flatten(), precision=3))

    def _fallback_intrinsics_from_fov(self, img_msg: Image):
        """Dùng khi không có CameraInfo: suy nội tại từ FOV ngang."""
        w = int(img_msg.width) if hasattr(img_msg, "width") else 1360
        h = int(img_msg.height) if hasattr(img_msg, "height") else 1024
        hfov = np.deg2rad(self.hfov_deg)
        fx = fy = (w / 2.0) / np.tan(hfov / 2.0)
        cx, cy = w / 2.0, h / 2.0
        self.K = np.array([[fx, 0, cx],
                           [0,  fy, cy],
                           [0,  0,  1]], dtype=np.float64)
        self.D = np.zeros((5, 1), dtype=np.float64)
        self.have_caminfo = True
        rospy.logwarn_throttle(5.0, "No CameraInfo -> fallback K from FOV %.1f deg (fx=%.1f)",
                               self.hfov_deg, fx)

    def _detect(self, gray):
        if self._use_new_api:
            corners, ids, _ = self.detector.detectMarkers(gray)
        else:
            aruco_dict, params = self.detector
            corners, ids, _ = cv2.aruco.detectMarkers(gray, aruco_dict, parameters=params)
        return corners, ids

    def cb_image(self, msg: Image):
        if not self.have_caminfo:
            # chờ CameraInfo; nếu không có thì fallback
            self._fallback_intrinsics_from_fov(msg)

        # BGR -> GRAY + tiền xử lý
        img  = self.bridge.imgmsg_to_cv2(msg, desired_encoding="bgr8")
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        if self.use_clahe:
            clahe = cv2.createCLAHE(
                clipLimit=self.clahe_clip,
                tileGridSize=(self.clahe_tiles, self.clahe_tiles)
            )
            gray = clahe.apply(gray)

        if self.median_ksize >= 3 and self.median_ksize % 2 == 1:
            gray = cv2.medianBlur(gray, self.median_ksize)

        # Detect
        corners, ids = self._detect(gray)

        if ids is not None and len(ids) > 0:
            # vẽ khung & ước lượng pose
            try:
                rvecs, tvecs, _ = cv2.aruco.estimatePoseSingleMarkers(
                    corners, self.marker_length, self.K, self.D
                )

                cv2.aruco.drawDetectedMarkers(img, corners, ids)
                for rvec, tvec in zip(rvecs, tvecs):
                    cv2.drawFrameAxes(img, self.K, self.D, rvec, tvec, self.axis_len, 2)

                # publish pose marker đầu tiên
                rvec = rvecs[0].reshape(3, 1)
                tvec = tvecs[0].reshape(3, 1)
                R, _ = cv2.Rodrigues(rvec)

                # R -> quaternion (ổn định với qw≈0)
                tr = np.trace(R)
                if tr > 0:
                    qw = np.sqrt(1.0 + tr) / 2.0
                    qx = (R[2, 1] - R[1, 2]) / (4.0 * qw)
                    qy = (R[0, 2] - R[2, 0]) / (4.0 * qw)
                    qz = (R[1, 0] - R[0, 1]) / (4.0 * qw)
                else:
                    # fallback an toàn
                    qw = np.sqrt(1.0 + tr) / 2.0 if tr > -1.0 else 1.0
                    qx = (R[2, 1] - R[1, 2]) / max(1e-6, 4.0 * qw)
                    qy = (R[0, 2] - R[2, 0]) / max(1e-6, 4.0 * qw)
                    qz = (R[1, 0] - R[0, 1]) / max(1e-6, 4.0 * qw)

                ps = PoseStamped()
                ps.header = msg.header
                ps.pose.position.x = float(tvec[0])
                ps.pose.position.y = float(tvec[1])
                ps.pose.position.z = float(tvec[2])
                ps.pose.orientation.x = float(qx)
                ps.pose.orientation.y = float(qy)
                ps.pose.orientation.z = float(qz)
                ps.pose.orientation.w = float(qw)
                self.pub_pose.publish(ps)
                
                                # ----- Publish pose trong frame Vehicle -----
                try:
                    ps_vehicle = ps
                    if self.use_tf and self.target_frame:
                        trans = self.tfbuf.lookup_transform(
                            self.target_frame,           # "Vehicle"
                            ps.header.frame_id,          # "GIRONA500/proscilica"
                            rospy.Time(0),
                            rospy.Duration(0.05)
                        )
                        ps_vehicle = do_transform_pose(ps, trans)
                        ps_vehicle.header.stamp = ps.header.stamp
                        ps_vehicle.header.frame_id = self.target_frame

                    self.pub_pose_vehicle.publish(ps_vehicle)
                except Exception as tf_err:
                    rospy.logwarn_throttle(
                        1.0,
                        "Transform pose -> %s failed: %s",
                        self.target_frame, str(tf_err)
                    )


                # ===== Step 5: Xuất target point & distance =====
                try:
                    # t trong frame ảnh/camera (m)
                    t = tvecs[0].reshape(3)
                    pt_cam = PointStamped()
                    pt_cam.header = msg.header
                    pt_cam.point.x = float(t[0])
                    pt_cam.point.y = float(t[1])
                    pt_cam.point.z = float(t[2])

                    # Nếu có TF và đặt target_frame, chuyển sang frame đích
                    pt_out = pt_cam
                    if getattr(self, "use_tf", False) and getattr(self, "target_frame", ""):
                        try:
                            pt_out = self.tfbuf.transform(
                                pt_cam, self.target_frame, rospy.Duration(0.05)
                            )
                        except Exception as tf_err:
                            rospy.logwarn_throttle(
                                1.0,
                                "TF %s -> %s failed: %s",
                                pt_cam.header.frame_id, self.target_frame, str(tf_err)
                            )

                    self.pub_target.publish(pt_out)

                    # Khoảng cách tới marker (Euclid) trong frame camera
                    dist = float(np.linalg.norm(t))
                    self.pub_range.publish(Float32(data=dist))
                except Exception as pub_err:
                    rospy.logwarn_throttle(2.0, "Target publish failed: %s", str(pub_err))

            except Exception as e:
                rospy.logwarn_throttle(2.0, "Pose estimation failed: %s", str(e))

        else:
            cv2.putText(
                img, "No marker", (20, 40),
                cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 200, 255), 2, cv2.LINE_AA
            )

        # debug image
        self.pub_dbg.publish(self.bridge.cv2_to_imgmsg(img, encoding="bgr8"))



if __name__ == "__main__":
    try:
        ArucoDetector()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass


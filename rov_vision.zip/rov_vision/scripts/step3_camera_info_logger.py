#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import rospy, yaml, os
from sensor_msgs.msg import CameraInfo

class CamInfoLogger:
    def __init__(self):
        self.topic = rospy.get_param("~camera_info_topic", "/camera/image_raw/camera_info")
        self.save_yaml = rospy.get_param("~save_yaml", True)
        self.out_dir = os.path.expanduser(rospy.get_param("~out_dir", "~/.ros"))
        self.once = False
        rospy.Subscriber(self.topic, CameraInfo, self.cb, queue_size=1)
        rospy.loginfo("Step3: subscribing %s", self.topic)

    def cb(self, msg):
        if self.once:
            return
        self.once = True

        w, h = msg.width, msg.height
        K = list(msg.K)            # 3x3 (row-major)
        D = list(msg.D)            # distortion coeffs
        fx, fy, cx, cy = K[0], K[4], K[2], K[5]

        rospy.loginfo("CameraInfo: %dx%d | fx=%.2f fy=%.2f cx=%.2f cy=%.2f | D=%s",
                      w, h, fx, fy, cx, cy, [round(d, 6) for d in D])

        # lưu YAML (chuẩn OpenCV/ROS)
        if self.save_yaml:
            os.makedirs(self.out_dir, exist_ok=True)
            data = {
                "image_width":  w,
                "image_height": h,
                "camera_name":  "sim_camera",
                "camera_matrix": {"rows": 3, "cols": 3, "data": K},
                "distortion_model": msg.distortion_model or "plumb_bob",
                "distortion_coefficients": {"rows": 1, "cols": len(D), "data": D},
                "rectification_matrix": {"rows": 3, "cols": 3, "data": list(msg.R)},
                "projection_matrix":    {"rows": 3, "cols": 4, "data": list(msg.P)}
            }
            path = os.path.join(self.out_dir, "sim_camera.yaml")
            with open(path, "w") as f:
                yaml.safe_dump(data, f, sort_keys=False)
            rospy.loginfo("Saved camera YAML -> %s", path)

if __name__ == "__main__":
    rospy.init_node("step3_camera_info_logger")
    CamInfoLogger()
    rospy.spin()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import rospy, time
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError

class FPSLogger:
    def __init__(self):
        self.image_topic = rospy.get_param("~image_topic", "/camera/image_raw")
        self.bridge = CvBridge()
        self.count = 0
        self.t0 = time.time()
        rospy.Subscriber(self.image_topic, Image, self.cb_image, queue_size=1)
        rospy.loginfo("Step2: subscribing %s", self.image_topic)

    def cb_image(self, msg):
        try:
            _ = self.bridge.imgmsg_to_cv2(msg, desired_encoding="bgr8")
        except CvBridgeError as e:
            rospy.logerr("cv_bridge error: %s", str(e))
            return
        self.count += 1
        now = time.time()
        if now - self.t0 >= 1.0:
            fps = self.count / (now - self.t0)
            rospy.loginfo("Camera FPS: %.1f", fps)
            self.count = 0
            self.t0 = now

if __name__ == "__main__":
    rospy.init_node("step2_fps_logger")
    FPSLogger()
    rospy.spin()

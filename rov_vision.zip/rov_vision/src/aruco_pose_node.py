#!/usr/bin/env python3
import rospy, cv2, cv2.aruco as aruco
from cv_bridge import CvBridge
from sensor_msgs.msg import Image, CameraInfo
from geometry_msgs.msg import PoseWithCovarianceStamped
from std_msgs.msg import Bool
import tf2_ros, geometry_msgs.msg as gm
import numpy as np

class ArucoPoseNode:
    def __init__(self):
        self.bridge = CvBridge()
        self.image_sub = rospy.Subscriber(
            rospy.get_param("~image_topic","/camera/image_raw/image_color"),
            Image, self.cb_image, queue_size=1, buff_size=2**24)
        self.info_sub  = rospy.Subscriber("/camera/camera_info", CameraInfo, self.cb_info, queue_size=1)

        self.pose_pub  = rospy.Publisher("/dock_pose", PoseWithCovarianceStamped, queue_size=1)
        self.flag_pub  = rospy.Publisher("/dock_in_sight", Bool, queue_size=1)

        self.tfbr = tf2_ros.TransformBroadcaster()
        self.K = None; self.D = None
        self.dict = aruco.getPredefinedDictionary(aruco.DICT_4X4_50)
        self.params = aruco.DetectorParameters_create()

        self.marker_id = rospy.get_param("~marker_id", 0)
        self.marker_size = rospy.get_param("~marker_size", 0.20)  # mét

    def cb_info(self, msg):
        self.K = np.array(msg.K, dtype=np.float32).reshape(3,3)
        self.D = np.array(msg.D, dtype=np.float32)

    def cb_image(self, msg):
        if self.K is None: return
        img = self.bridge.imgmsg_to_cv2(msg, desired_encoding="bgr8")
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        corners, ids, _ = aruco.detectMarkers(gray, self.dict, parameters=self.params)
        seen = False
        if ids is not None:
            for i, mid in enumerate(ids.flatten()):
                if int(mid) == self.marker_id:
                    rvec, tvec, _ = aruco.estimatePoseSingleMarkers(
                        corners[i], self.marker_size, self.K, self.D)
                    # tvec: camera->marker in camera frame
                    rvec, tvec = rvec[0,0,:], tvec[0,0,:]
                    seen = True

                    # publish TF camera_optical -> dock
                    T = gm.TransformStamped()
                    T.header.stamp = rospy.Time.now()
                    T.header.frame_id = "camera_optical"
                    T.child_frame_id  = "dock"
                    R,_ = cv2.Rodrigues(rvec)
                    q = self.R_to_q(R)
                    T.transform.translation.x = tvec[0]
                    T.transform.translation.y = tvec[1]
                    T.transform.translation.z = tvec[2]
                    T.transform.rotation.x = q[0]; T.transform.rotation.y = q[1]
                    T.transform.rotation.z = q[2]; T.transform.rotation.w = q[3]
                    self.tfbr.sendTransform(T)

                    # publish PoseWithCovarianceStamped (trong camera_optical)
                    P = PoseWithCovarianceStamped()
                    P.header = T.header
                    P.pose.pose.position.x, P.pose.pose.position.y, P.pose.pose.position.z = tvec
                    P.pose.pose.orientation.x, P.pose.pose.orientation.y, P.pose.pose.orientation.z, P.pose.pose.orientation.w = q
                    P.pose.covariance = [0]*36
                    P.pose.covariance[0]=P.pose.covariance[7]=P.pose.covariance[14]=0.01
                    P.pose.covariance[21]=P.pose.covariance[28]=P.pose.covariance[35]=0.02
                    self.pose_pub.publish(P)
                    break
        self.flag_pub.publish(Bool(data=seen))

    @staticmethod
    def R_to_q(R):
        # Convert rotation matrix to quaternion (x,y,z,w)
        q = np.empty(4)
        tr = R[0,0]+R[1,1]+R[2,2]
        if tr>0:
            S = np.sqrt(tr+1.0)*2
            q[3]=0.25*S
            q[0]=(R[2,1]-R[1,2])/S
            q[1]=(R[0,2]-R[2,0])/S
            q[2]=(R[1,0]-R[0,1])/S
        else:
            i = np.argmax([R[0,0],R[1,1],R[2,2]])
            if i==0:
                S=np.sqrt(1.0+R[0,0]-R[1,1]-R[2,2])*2
                q[3]=(R[2,1]-R[1,2])/S; q[0]=0.25*S
                q[1]=(R[0,1]+R[1,0])/S; q[2]=(R[0,2]+R[2,0])/S
            elif i==1:
                S=np.sqrt(1.0-R[0,0]+R[1,1]-R[2,2])*2
                q[3]=(R[0,2]-R[2,0])/S; q[0]=(R[0,1]+R[1,0])/S
                q[1]=0.25*S; q[2]=(R[1,2]+R[2,1])/S
            else:
                S=np.sqrt(1.0-R[0,0]-R[1,1]+R[2,2])*2
                q[3]=(R[1,0]-R[0,1])/S; q[0]=(R[0,2]+R[2,0])/S
                q[1]=(R[1,2]+R[2,1])/S; q[2]=0.25*S
        return q

if __name__ == "__main__":
    rospy.initNode("aruco_pose_node")
    ArucoPoseNode()
    rospy.spin()

